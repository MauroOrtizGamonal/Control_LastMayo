package com.softtek;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IGRepositorio <T,ID> extends JpaRepository <T,ID>{
}
