package com.softtek;

public class Crud {
}
