package com.softtek;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins= "http://localhost:4200/")
@RequestMapping("/usuarios")
class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping
    public Usuario guardarUsuario(@RequestBody Usuario usuario) {
        try {
            return usuarioService.guardarUsuario(usuario);
        } catch (Exception e) {
            return null;
        }
    }
}
