package com.softtek;

public interface IUsuario extends IGRepositorio <Usuario,Integer> {
}
