package com.softtek;

public interface ICrud {
}
