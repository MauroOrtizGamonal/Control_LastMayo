
import { Routes } from '@angular/router';
import { InicioComponent } from './inicio/inicio.component';
import { AcercaDeComponent } from './acerca-de/acerca-de.component';
import { ContactoComponent } from './contacto/contacto.component';
import { FormularioUsuarioComponent } from './formulario-usuario/formulario-usuario.component';

export const routes: Routes = [
  { path: 'formulario-usuario', component: FormularioUsuarioComponent },
  { path: 'inicio', component: InicioComponent },
  { path: 'acerca-de', component: AcercaDeComponent },
  { path: 'contacto', component: ContactoComponent },
];

export class AppRoutingModule { }
