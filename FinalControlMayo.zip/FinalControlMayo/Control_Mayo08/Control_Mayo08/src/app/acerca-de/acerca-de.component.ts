import { Component } from '@angular/core';

@Component({
  selector: 'app-acerca-de',
  standalone: true,
  imports: [],
  templateUrl: './acerca-de.component.html',
  styleUrl: './acerca-de.component.css'
})
export class AcercaDeComponent {

}
