import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { UsuarioService } from '../formulario-usuario.service'; // Updated service name

interface Usuario {
  nombre: string;
  correo: string;
}

@Component({
  selector: 'app-formulario-usuario',
  templateUrl: './formulario-usuario.component.html',
  styleUrls: ['./formulario-usuario.component.css'],
  standalone: true,
  imports: [ReactiveFormsModule],
  providers: [HttpClient]
})
export class FormularioUsuarioComponent implements OnInit {
  formulario!: FormGroup;

  constructor(private fb: FormBuilder, private usuarioService: UsuarioService, private http: HttpClient) {} // Inject HttpClient

  ngOnInit(): void {
    this.formulario = this.fb.group({
      nombre: ['', Validators.required],
      correo: ['', [Validators.required, Validators.email]],
    });
  }

  get f() {
    return this.formulario.controls;
  }

  onSubmit() {
    if (this.formulario.valid) {
      const usuario: Usuario = this.formulario.value;

      this.usuarioService.guardarUsuario(usuario);
      console.log('Formulario válido:', usuario);
    } else {
      console.log('Formulario inválido');
    }
  }
}
