import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; // Import for potential API calls

interface Usuario {
  nombre: string;
  correo: string;
}

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

  constructor(private http: HttpClient) { } // Inject HttpClient if making API calls

  guardarUsuario(usuario: Usuario) {
    // Implement logic to save user data (e.g., API call, local storage)
    console.log('Usuario guardado:', usuario); // Placeholder for now
  }
}
